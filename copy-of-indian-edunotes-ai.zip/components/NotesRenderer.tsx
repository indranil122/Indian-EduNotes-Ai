
import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { OutputStyle } from '../types';
import { Spinner } from './Spinner';

interface NotesRendererProps {
  content: string;
  outputStyle: OutputStyle;
  isLoading: boolean;
  error: string | null;
}

const DiagramPlaceholder: React.FC<{ description: string }> = ({ description }) => (
  <div className="my-4 p-4 border-2 border-dashed border-slate-500 rounded-lg bg-slate-700/50 text-center">
    <p className="font-semibold text-slate-300 text-lg">🎨 Diagram Placeholder</p>
    <p className="text-slate-400 italic mt-1">{description}</p>
  </div>
);

const renderMarkdownComponents = (outputStyle: OutputStyle) => {
  let heading1Classes = "text-3xl font-bold mt-6 mb-4 text-sky-400";
  let heading2Classes = "text-2xl font-semibold mt-5 mb-3 text-sky-300";
  let heading3Classes = "text-xl font-semibold mt-4 mb-2 text-sky-200";
  let paragraphClasses = "my-2 leading-relaxed";
  let listClasses = "list-disc pl-6 my-2 space-y-1";
  let listItemClasses = "pb-1"; // Small bottom padding for list items
  let strongClasses = "font-semibold";
  let emClasses = "italic";
  let linkClasses = "text-cyan-400 hover:text-cyan-300 underline";
  let hrClasses = "my-6 border-slate-600";

  switch (outputStyle) {
    case OutputStyle.Notebook:
      heading1Classes = "text-3xl font-bold mt-6 mb-4 text-blue-700";
      heading2Classes = "text-2xl font-semibold mt-5 mb-3 text-blue-600";
      heading3Classes = "text-xl font-semibold mt-4 mb-2 text-blue-500";
      paragraphClasses = "my-2 leading-loose"; // More relaxed for notebook
      listClasses = "list-disc pl-6 my-2 space-y-1 marker:text-blue-600";
      strongClasses = "font-bold text-gray-800";
      linkClasses = "text-indigo-600 hover:text-indigo-500 underline";
      hrClasses = "my-6 border-gray-300";
      break;
    case OutputStyle.Pdf:
      heading1Classes = "text-3xl font-bold mt-6 mb-4 text-slate-800";
      heading2Classes = "text-2xl font-semibold mt-5 mb-3 text-slate-700";
      heading3Classes = "text-xl font-semibold mt-4 mb-2 text-slate-600";
      listClasses = "list-disc pl-6 my-2 space-y-1 marker:text-slate-700";
      strongClasses = "font-bold text-black";
      linkClasses = "text-sky-600 hover:text-sky-500 underline";
      hrClasses = "my-6 border-gray-300";
      break;
    case OutputStyle.Handwriting:
      heading1Classes = "text-3xl font-bold mt-6 mb-4 text-purple-700";
      heading2Classes = "text-2xl font-semibold mt-5 mb-3 text-purple-600";
      heading3Classes = "text-xl font-semibold mt-4 mb-2 text-purple-500";
      paragraphClasses = "my-2 leading-relaxed tracking-wide"; // Wider tracking for handwriting
      listClasses = "list-[식을] pl-6 my-2 space-y-1.5 marker:text-purple-600"; // Custom list style for handwriting
      strongClasses = "font-bold text-indigo-800";
      emClasses = "italic";
      linkClasses = "text-violet-600 hover:text-violet-500 underline";
      hrClasses = "my-6 border-purple-300";
      break;
  }


  return {
    h1: ({node, ...props}: any) => <h1 className={heading1Classes} {...props} />,
    h2: ({node, ...props}: any) => <h2 className={heading2Classes} {...props} />,
    h3: ({node, ...props}: any) => <h3 className={heading3Classes} {...props} />,
    p: ({ node, children, ...props }: any) => {
      const childNode = node?.children?.[0];
      if (childNode?.type === 'text') {
        const diagramMatch = childNode.value.match(/\[Diagram: (.*?)\]/);
        if (diagramMatch) {
          return <DiagramPlaceholder description={diagramMatch[1]} />;
        }
        // Remove voice summary markers before rendering
        if (childNode.value.startsWith('---VOICE_SUMMARY_START---') || childNode.value.startsWith('---VOICE_SUMMARY_END---')) {
            return null;
        }
      }
      return <p className={paragraphClasses} {...props}>{children}</p>;
    },
    ul: ({node, ...props}: any) => <ul className={listClasses} {...props} />,
    ol: ({node, ...props}: any) => <ol className={`${listClasses} list-decimal`} {...props} />,
    li: ({node, ...props}: any) => <li className={listItemClasses} {...props} />,
    strong: ({node, ...props}: any) => <strong className={strongClasses} {...props} />,
    em: ({node, ...props}: any) => <em className={emClasses} {...props} />,
    a: ({node, ...props}: any) => <a className={linkClasses} target="_blank" rel="noopener noreferrer" {...props} />,
    hr: ({node, ...props}: any) => <hr className={hrClasses} {...props} />,
    // Add more custom renderers if needed (e.g., blockquote, code, table)
    table: ({node, ...props}: any) => <div className="overflow-x-auto my-4"><table className="min-w-full border border-slate-500 bg-slate-700/30" {...props} /></div>,
    thead: ({node, ...props}: any) => <thead className="bg-slate-600/50" {...props} />,
    th: ({node, ...props}: any) => <th className="p-2 border border-slate-500 text-left" {...props} />,
    td: ({node, ...props}: any) => <td className="p-2 border border-slate-500" {...props} />,

  };
};


export const NotesRenderer: React.FC<NotesRendererProps> = ({
  content,
  outputStyle,
  isLoading,
  error,
}) => {
  let styleClasses = 'p-6 lg:p-8 rounded-lg shadow-xl overflow-y-auto h-[calc(100vh-220px)] lg:h-auto lg:max-h-[calc(100vh-160px)] transition-all duration-300 ease-in-out ';
  // Base text color for general content, specific components will override
  let baseTextColorClass = 'text-slate-100';


  switch (outputStyle) {
    case OutputStyle.Notebook:
      styleClasses += 'bg-amber-50 font-notebook ';
      styleClasses += 'bg-[linear-gradient(to_bottom,transparent_29px,#e0e0e0_30px)] bg-[length:100%_30px]';
      baseTextColorClass = 'text-gray-700';
      break;
    case OutputStyle.Pdf:
      styleClasses += 'bg-white font-pdf ';
      baseTextColorClass = 'text-slate-800';
      break;
    case OutputStyle.Handwriting:
      styleClasses += 'bg-yellow-50 font-handwriting text-lg ';
      styleClasses += 'bg-[linear-gradient(to_bottom,transparent_34px,#d1d5db_35px)] bg-[length:100%_35px]';
      baseTextColorClass = 'text-indigo-700';
      break;
    default:
      styleClasses += 'bg-slate-700 font-sans ';
      baseTextColorClass = 'text-slate-200';
  }

  if (isLoading) {
    return (
      <section aria-live="polite" aria-busy="true" className={`lg:w-2/3 w-full flex items-center justify-center ${styleClasses} min-h-[300px]`}>
        <Spinner />
      </section>
    );
  }

  if (error) {
    return (
      <section role="alert" className={`lg:w-2/3 w-full flex flex-col items-center justify-center ${styleClasses} min-h-[300px] bg-red-800/20 border-red-500`}>
        <div className="text-center p-4 rounded-md bg-red-100">
          <h3 className="text-2xl font-semibold text-red-700 mb-3">⚠️ Error</h3>
          <p className="text-red-600">{error}</p>
          <p className="text-sm text-red-500 mt-2">Please check your query or network connection.</p>
        </div>
      </section>
    );
  }

  if (!content) {
    return (
      <section aria-label="Notes output area" className={`lg:w-2/3 w-full flex items-center justify-center ${styleClasses} min-h-[300px]`}>
        <div className="text-center text-slate-500">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <p className="text-xl">Your generated notes will appear here.</p>
          <p className="text-sm mt-1">Enter a query and click "Generate Notes" to begin.</p>
        </div>
      </section>
    );
  }

  return (
    <section aria-label={`Generated notes in ${outputStyle} style`} className={`lg:w-2/3 w-full ${styleClasses} ${baseTextColorClass}`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={renderMarkdownComponents(outputStyle)}
        // The children prop is the markdown string
      >
        {content}
      </ReactMarkdown>
    </section>
  );
};
