
import React from 'react';
import { OutputStyle } from '../types';

interface InputControlsProps {
  query: string;
  setQuery: (query: string) => void;
  outputStyle: OutputStyle;
  setOutputStyle: (style: OutputStyle) => void;
  voiceNarrationEnabled: boolean;
  setVoiceNarrationEnabled: (enabled: boolean) => void;
  onGenerate: () => void;
  isLoading: boolean;
}

const commonInputClass = "w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition-all duration-200 text-slate-100 placeholder-slate-400";
const commonButtonClass = "w-full p-3 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center gap-2";
const primaryButtonClass = `${commonButtonClass} bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed`;
const labelClass = "block mb-2 text-sm font-medium text-slate-300";

export const InputControls: React.FC<InputControlsProps> = ({
  query,
  setQuery,
  outputStyle,
  setOutputStyle,
  voiceNarrationEnabled,
  setVoiceNarrationEnabled,
  onGenerate,
  isLoading,
}) => {
  return (
    <aside className="lg:w-1/3 w-full p-6 bg-slate-800 rounded-lg shadow-xl space-y-6">
      <div>
        <label htmlFor="queryInput" className={labelClass}>
          📚 Your Query
        </label>
        <textarea
          id="queryInput"
          rows={4}
          className={`${commonInputClass} min-h-[100px] resize-y`}
          placeholder="e.g., Class 10 CBSE Science Chapter 2 notes, or ICSE Class 9 Geography India Climate summary"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          disabled={isLoading}
        />
        <p className="mt-1 text-xs text-slate-400">Enter any Indian school subject/topic.</p>
      </div>

      <div>
        <label htmlFor="outputStyleSelect" className={labelClass}>
          🎨 Output Style
        </label>
        <select
          id="outputStyleSelect"
          className={commonInputClass}
          value={outputStyle}
          onChange={(e) => setOutputStyle(e.target.value as OutputStyle)}
          disabled={isLoading}
        >
          <option value={OutputStyle.Notebook}>📝 Notebook Style</option>
          <option value={OutputStyle.Pdf}>📄 Clean Style (PDF-like)</option>
          <option value={OutputStyle.Handwriting}>✍️ Handwriting Style</option>
        </select>
      </div>

      <div className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
        <label htmlFor="voiceToggle" className="text-sm font-medium text-slate-300 cursor-pointer">
          🗣️ Enable Voice Summary
        </label>
        <button
          type="button"
          id="voiceToggle"
          onClick={() => setVoiceNarrationEnabled(!voiceNarrationEnabled)}
          disabled={isLoading}
          className={`${
            voiceNarrationEnabled ? 'bg-sky-500' : 'bg-slate-600'
          } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 focus:ring-offset-slate-800`}
          aria-pressed={voiceNarrationEnabled}
        >
          <span className="sr-only">Enable Voice Summary</span>
          <span
            aria-hidden="true"
            className={`${
              voiceNarrationEnabled ? 'translate-x-5' : 'translate-x-0'
            } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
          />
        </button>
      </div>

      <button
        onClick={onGenerate}
        disabled={isLoading}
        className={primaryButtonClass}
      >
        {isLoading ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Generating...
          </>
        ) : (
          '✨ Generate Notes'
        )}
      </button>
    </aside>
  );
};
