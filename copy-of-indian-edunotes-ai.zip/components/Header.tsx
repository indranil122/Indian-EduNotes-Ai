
import React from 'react';
import { APP_TITLE } from '../constants';

export const Header: React.FC = () => {
  return (
    <header className="w-full py-6 text-center">
      <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-sky-400 via-cyan-300 to-emerald-400">
        {APP_TITLE}
      </h1>
      <p className="text-slate-300 mt-2 text-lg">Your AI-powered guide to Indian educational topics.</p>
    </header>
  );
};
