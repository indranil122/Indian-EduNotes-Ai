
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { OutputStyle, NoteGenerationResult, GroundingMetadata } from '../types';
import { GEMINI_MODEL_NAME, VOICE_SUMMARY_START_MARKER, VOICE_SUMMARY_END_MARKER, GEMINI_API_TIMEOUT } from '../constants';

const getApiKey = (): string => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY environment variable is not set.");
    throw new Error("API Key not configured. Please contact support or check application settings.");
  }
  return apiKey;
};

const ai = new GoogleGenAI({ apiKey: getApiKey() });

const constructPrompt = (query: string, outputStyle: OutputStyle, voiceNarrationRequested: boolean): string => {
  // Note: The outputStyle itself is handled by CSS in the frontend.
  // This prompt focuses on the content structure.
  return `
You are a highly knowledgeable, detail-oriented educational assistant trained on the Indian education system.
Your task is to generate educational notes based on the following user query: "${query}".

Follow these instructions strictly:
1.  **Subject Focus:** The query relates to an Indian school subject/topic (from any class and board: CBSE, ICSE, State Boards, etc.).
2.  **Output Format:** The notes should be structured for easy readability, mimicking a well-organized notebook. Use Markdown formatting.
3.  **Language:** Use simple, student-friendly language suitable for the target student demographic implied by the query.
4.  **Structure (Use Markdown):**
    *   **Title:** Start with a clear Markdown H1 heading " # Title: [Chapter/Topic Name]".
    *   **Headings and Subheadings:** Use Markdown H2 (##) for main sections and H3 (###) for sub-sections for clear organization.
    *   **Bullet Points:** Use Markdown bullet points (\`* \` or \`- \`) for lists and key points.
    *   **Definitions and Formulas:** Clearly label sections like "## Important Definitions" and "## Key Formulas". List them accurately using bullet points or paragraphs.
    *   **Key Concepts:** Explain key concepts thoroughly under appropriate subheadings.
    *   **Diagrams:** If a diagram would be beneficial, mention it textually like "[Diagram: Description of what the diagram would show]". Do not attempt to generate image data or HTML images.
    *   **Examples:** Include relevant examples. If appropriate, mention "### Examples from NCERT/Board Text:".
    *   **Important Points:** Highlight any other "## Important Points" or "## Key Takeaways".
    *   **Summary/Key Takeaways:** Conclude with a "## Summary" or "## Key Takeaways" section.
5.  **Content Source:** Where relevant, draw upon information typically found in NCERT textbooks or textbooks from common Indian educational boards. Ensure factual accuracy.
6.  **Tone:** Maintain an encouraging, helpful, and teacher-like tone.

${voiceNarrationRequested ? `
7.  **Voice Narration Summary (Mandatory if requested):**
    IMPORTANT: After all the main notes, include a concise summary specifically for voice narration.
    This summary should be clearly demarcated. Start it with a new line containing only "${VOICE_SUMMARY_START_MARKER}" and end it with a new line containing only "${VOICE_SUMMARY_END_MARKER}".
    The voice summary should be a teacher-like, clear, natural-sounding overview, covering the main points of the topic in 2-3 short paragraphs. It should be distinct from the main content's summary.
` : ''}

Produce the entire output in Markdown format. Ensure all headings, lists, and emphasis are done using Markdown syntax (e.g., #, ##, ###, *, **, etc.). Do not include any HTML tags.
`;
};

export const generateNotesFromGemini = async (
  query: string,
  outputStyle: OutputStyle,
  voiceNarrationRequested: boolean
): Promise<NoteGenerationResult> => {
  const fullPrompt = constructPrompt(query, outputStyle, voiceNarrationRequested);

  let timeoutHandle: ReturnType<typeof setTimeout>;

  const apiCallPromise = ai.models.generateContent({ // Call with a single argument object
    model: GEMINI_MODEL_NAME,
    contents: fullPrompt,
    // No specific config like systemInstruction or thinkingConfig needed for this use case beyond the main prompt.
    // If other model parameters were needed, they would go into a 'config: {}' property here.
  });

  const timeoutPromise = new Promise<never>((_, reject) => { // This promise only rejects
    timeoutHandle = setTimeout(() => {
      const timeoutError = new Error("The request to the AI service timed out. Please try again.");
      timeoutError.name = 'AbortError'; // Mimic AbortError for the existing catch block
      reject(timeoutError);
    }, GEMINI_API_TIMEOUT);
  });

  try {
    const response = await Promise.race([apiCallPromise, timeoutPromise]);
    clearTimeout(timeoutHandle!); // Clear timeout if apiCallPromise won (resolved or rejected before timeout)

    let mainContent = response.text;
    let voiceSummary: string | undefined = undefined;

    if (voiceNarrationRequested) {
      const startIndex = mainContent.indexOf(VOICE_SUMMARY_START_MARKER);
      const endIndex = mainContent.indexOf(VOICE_SUMMARY_END_MARKER);

      if (startIndex !== -1 && endIndex !== -1 && endIndex > startIndex) {
        voiceSummary = mainContent.substring(startIndex + VOICE_SUMMARY_START_MARKER.length, endIndex).trim();
        // Remove the voice summary part (including markers) from the main content
        mainContent = mainContent.substring(0, startIndex).trim() + mainContent.substring(endIndex + VOICE_SUMMARY_END_MARKER.length).trim();
      } else {
        console.warn("Voice summary markers not found or improperly formatted in Gemini response.");
      }
    }
    
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata as GroundingMetadata | undefined;
    if (groundingMetadata?.groundingChunks && groundingMetadata.groundingChunks.length > 0) {
        // console.log("Content may be grounded with web search results:", groundingMetadata.groundingChunks);
        // Here you could append sources to mainContent if desired.
        // For this app, we will not display them unless specifically requested by user prompt.
    }

    return { mainContent, voiceSummary };

  } catch (error: any) {
    clearTimeout(timeoutHandle!); // Ensure timeout is cleared on any error path

    if (error.name === 'AbortError') { // This will catch our custom timeout error
      console.error("Gemini API request timed out (client-side implementation).");
      // The error object (timeoutError) already has the correct message.
      throw error;
    }
    
    console.error("Error calling Gemini API:", error);
    let message = "An unexpected error occurred while generating notes.";
    if (error.message) {
        message = `API Error: ${error.message}`; // Matches original error construction
    }
    throw new Error(message);
  }
};
