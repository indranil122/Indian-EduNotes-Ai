
export enum OutputStyle {
  Notebook = 'notebook',
  Pdf = 'pdf', // Represents a clean, PDF-like visual style, not actual PDF generation
  Handwriting = 'handwriting',
}

export interface NoteGenerationResult {
  mainContent: string;
  voiceSummary?: string;
}

export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web: GroundingChunkWeb;
}

export interface GroundingMetadata {
  groundingChunks?: GroundingChunk[];
}
