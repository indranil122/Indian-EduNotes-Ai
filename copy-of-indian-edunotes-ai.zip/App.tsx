
import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { InputControls } from './components/InputControls';
import { NotesRenderer } from './components/NotesRenderer';
import { generateNotesFromGemini } from './services/geminiService';
import { OutputStyle, type NoteGenerationResult } from './types';
import { Toaster, toast } from 'react-hot-toast';

const App: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [outputStyle, setOutputStyle] = useState<OutputStyle>(OutputStyle.Notebook);
  const [voiceNarrationEnabled, setVoiceNarrationEnabled] = useState<boolean>(false);
  const [generatedContent, setGeneratedContent] = useState<NoteGenerationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState<string | null>(null);

  useEffect(() => {
    // Simulate API key loading, in a real app this would be securely managed
    // For this exercise, we assume process.env.API_KEY is available in geminiService
    // This is just to satisfy the UI requirement of needing an API key state for a potential input
    // However, instructions say: "The API key must be obtained exclusively from the environment variable process.env.API_KEY"
    // So, no UI for API key input. This state is illustrative if requirements changed.
    const loadedApiKey = process.env.API_KEY;
    if (loadedApiKey) {
      setApiKey(loadedApiKey);
    } else {
      console.warn("API_KEY environment variable not found. Gemini API calls will fail.");
      // toast.error("API Key not configured. Please set the API_KEY environment variable.");
      // No direct user error for API key here as per instructions.
    }
  }, []);

  const handleGenerateNotes = useCallback(async () => {
    if (!query.trim()) {
      toast.error('Please enter a topic or query.');
      return;
    }
    
    // As per instruction: The API key must be obtained exclusively from the environment variable process.env.API_KEY
    // The geminiService will handle this. A check here is more for UX before attempting a call.
    if (!process.env.API_KEY && !apiKey) { // Check both, though process.env.API_KEY is primary
        toast.error("API Key is not configured. Cannot generate notes.", { duration: 4000 });
        setError("API Key is not configured. The application cannot contact the AI service.");
        return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedContent(null); // Clear previous content

    try {
      const result = await generateNotesFromGemini(query, outputStyle, voiceNarrationEnabled);
      setGeneratedContent(result);
      toast.success('Notes generated successfully!');

      if (voiceNarrationEnabled && result.voiceSummary) {
        try {
          const utterance = new SpeechSynthesisUtterance(result.voiceSummary);
          utterance.lang = 'en-IN'; // Set language for Indian English accent if available
          window.speechSynthesis.speak(utterance);
        } catch (speechError) {
          console.error("Speech synthesis error:", speechError);
          toast.error("Could not play voice summary.");
        }
      }
    } catch (e: any) {
      console.error("Error generating notes:", e);
      setError(e.message || 'Failed to generate notes. Check console for details.');
      toast.error(e.message || 'Failed to generate notes.');
    } finally {
      setIsLoading(false);
    }
  }, [query, outputStyle, voiceNarrationEnabled, apiKey]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-white flex flex-col items-center p-4">
      <Toaster position="top-center" reverseOrder={false} />
      <Header />
      <main className="container mx-auto mt-4 flex flex-col lg:flex-row gap-6 w-full max-w-7xl p-4 bg-slate-800 bg-opacity-70 backdrop-blur-md shadow-2xl rounded-xl">
        <InputControls
          query={query}
          setQuery={setQuery}
          outputStyle={outputStyle}
          setOutputStyle={setOutputStyle}
          voiceNarrationEnabled={voiceNarrationEnabled}
          setVoiceNarrationEnabled={setVoiceNarrationEnabled}
          onGenerate={handleGenerateNotes}
          isLoading={isLoading}
        />
        <NotesRenderer
          content={generatedContent?.mainContent || ''}
          outputStyle={outputStyle}
          isLoading={isLoading}
          error={error}
        />
      </main>
       <footer className="text-center py-6 mt-auto text-slate-400 text-sm">
        <p>&copy; {new Date().getFullYear()} Indian EduNotes AI. Powered by Gemini.</p>
      </footer>
    </div>
  );
};

export default App;
