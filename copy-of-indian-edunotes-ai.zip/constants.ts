
export const GEMINI_MODEL_NAME = 'gemini-2.5-flash-preview-04-17'; // General text tasks
export const GEMINI_API_TIMEOUT = 60000; // 60 seconds for API requests

export const APP_TITLE = "Indian EduNotes AI";

export const VOICE_SUMMARY_START_MARKER = "---VOICE_SUMMARY_START---";
export const VOICE_SUMMARY_END_MARKER = "---VOICE_SUMMARY_END---";
